const wa="https://wa.me/967775518031",group="https://chat.whatsapp.com/BewBwnAqdOyBywhAlp1fuF?s=sh&p=a&mlu=0";
document.getElementById("waTop").href=wa;document.getElementById("waBtn").href=wa;document.getElementById("groupBtn").href=group;document.getElementById("year").textContent=new Date().getFullYear();
let products=[];
async function load(){products=await fetch("/api/products").then(r=>r.json());render(products);}
function render(list){document.getElementById("count").textContent=list.length;document.getElementById("products").innerHTML=list.map(p=>`
<article class="card"><div class="pic" style="${p.image?`background-image:url('${p.image}')`:''}"><span>${p.badge||"متاح"}</span></div>
<div class="body"><small>${p.category}</small><h3>${p.title}</h3><p>${p.description}</p><div class="row"><b>${p.price}</b><a class="buy" target="_blank" href="${wa}?text=${encodeURIComponent("أريد الاستفسار عن: "+p.title)}">طلب عبر واتساب</a></div></div></article>`).join("")||"<p>لا توجد منتجات حاليًا.</p>";}
document.getElementById("search").addEventListener("input",e=>{const q=e.target.value.trim();render(products.filter(p=>(p.title+" "+p.description).includes(q)));});load();